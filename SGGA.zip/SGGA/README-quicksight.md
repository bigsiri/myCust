# Pipeline QuickSight - Guide Utilisateur

## 📋 Vue d'ensemble

Ce pipeline automatise le déploiement des ressources Amazon QuickSight à travers différents environnements (dev → accept → preprod → prod). Il permet l'export, la validation et le déploiement de dashboards, datasets, datasources, analyses et thèmes de manière contrôlée et reproductible.

## 🎯 Fonctionnalités

### ✅ Assets Supportés
- **📊 Dashboards** - Tableaux de bord et visualisations
- **📋 Datasets** - Jeux de données et modèles
- **🔌 Datasources** - Sources de données et connexions
- **📈 Analyses** - Analyses et rapports
- **🎨 Themes** - Thèmes visuels et palettes de couleurs

### ✅ Capacités du Pipeline
- **Export automatisé** depuis l'environnement source
- **Validation** des configurations avant déploiement
- **Déploiement multi-environnements** avec configurations spécifiques
- **Substitution des paramètres** selon l'environnement
- **Support multi-comptes** AWS avec remplacement automatique des IDs de compte
- **Surveillance** et reporting des déploiements

## 🏗️ Architecture du Pipeline

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Validation    │ -> │     Export       │ -> │   Déploiement   │
│   & Discovery   │    │   (dev/source)   │    │  (accept/preprod│
│                 │    │                  │    │      /prod)     │
└─────────────────┘    └──────────────────┘    └─────────────────┘
```

### Étapes du Pipeline

1. **🔍 Validation** - Vérification de la configuration formation.json
2. **📡 Discovery** - Découverte des assets dans QuickSight source
3. **📦 Export** - Export des assets vers un bundle ZIP
4. **🚀 Déploiement Accept** - Déploiement automatique sur Accept
5. **🚀 Déploiement PreProd** - Déploiement automatique sur PreProd
6. **🚀 Déploiement Production** - Déploiement automatique sur Production

## 📁 Structure des Fichiers

```
Deploy/
├── quicksight/
│   ├── exports/
│   │   └── formation.json                 # Configuration des assets à déployer
│   └── environments/
│       ├── dev.yaml                      # Configuration environnement dev
│       ├── accept.yaml                   # Configuration environnement accept
│       ├── preprod.yaml                  # Configuration environnement preprod
│       └── prd.yaml                      # Configuration environnement prod
└── templates/
    ├── deploy-quicksight.yaml            # Pipeline principal
    ├── jobs/
    │   ├── quicksight-export.yaml        # Job d'export
    │   └── quicksight-deploy.yaml        # Job de déploiement
    └── tasks/
        ├── quicksight-validate.yaml      # Validation
        ├── quicksight-export.yaml        # Export des assets
        ├── quicksight-deploy.yaml        # Déploiement des assets
        └── download-artifacts.yaml       # Téléchargement des artefacts
```

## ⚙️ Configuration

### 1. **formation.json** - Configuration des Assets

Le fichier `Deploy/quicksight/exports/formation.json` définit quels assets QuickSight doivent être exportés et déployés :

```json
{
  "export_name": "Formation Dashboard Suite",
  "description": "Formation analytics dashboard and related assets",
  "source_environment": "dev",
  "target_environment": "accept",
  
  "dashboards": [
    {
      "DashboardId": "c4041070-917b-44a4-a80b-37ff669dc5b4",
      "Name": "Formation Participation Migration"
    }
  ],
  
  "datasets": [
    {
      "DataSetId": "formation-dataset-migration",
      "Name": "Formation Dataset for Migration"
    }
  ],
  
  "datasources": [
    {
      "DataSourceId": "a6988ac7-ab47-461f-bafd-6a55855baf7c",
      "Name": "SD_COMPTOIR_DONNEES",
      "environment_overrides": {
        "accept": {
          "DataSourceParameters": {
            "AuroraPostgreSqlParameters": {
              "Host": "sgga-accept-rds-cluster.amazonaws.com",
              "Port": 5432,
              "Database": "sgga_app_ac_01"
            }
          }
        }
      }
    }
  ],
  
  "themes": [
    {
      "ThemeId": "formation-corporate-theme",
      "Name": "Formation Corporate Theme",
      "environment_overrides": {
        "accept": {
          "Configuration": {
            "DataColorPalette": {
              "Colors": ["#1f77b4", "#ff7f0e", "#2ca02c"]
            }
          }
        }
      }
    }
  ]
}
```

### 2. **Fichiers d'Environnement**

Chaque environnement a son fichier de configuration dans `Deploy/environments/quicksight/` :

#### **dev.yaml**
```yaml
variables:
  - name: aws_region
    value: "ca-central-1"
  - name: aws_account_id
    value: "216016857543"
  - name: deployment_bucket
    value: "sgga-dev-quicksight-siri"
  - name: service_account_name
    value: "service_account.sgga_client_cicd_dev"
  - name: export_role
    value: "arn:aws:iam::216016857543:role/sgga-dev-client-ecs"
  - name: deploy_role
    value: "arn:aws:iam::216016857543:role/sgga-dev-client-ecs"
```

#### **accept.yaml**
```yaml
variables:
  - name: aws_region
    value: "ca-central-1"
  - name: aws_account_id
    value: "968916078985"
  - name: deployment_bucket
    value: "sgga-accept-quicksight-siri"
  # ... autres variables spécifiques à accept
```

## 🚀 Utilisation du Pipeline

### Paramètres du Pipeline

Le pipeline principal `quicksight-pipeline.yml` accepte ces paramètres :

- **`export_config_file`** (défaut: "all")
    - Fichier de configuration d'export à utiliser
    - Valeurs possibles : "all", "formation", ou nom de fichier custom

- **`source_environment`** (défaut: "dev")
    - Environnement source pour l'export
    - Valeurs possibles : "dev", "accept", "preprod"

- **`enable_gitops_cleanup`** (défaut: false)
    - Active le nettoyage GitOps après déploiement

### Déclenchement Manuel

```yaml
# Dans Azure DevOps, utiliser ces paramètres :
export_config_file: "formation"     # ou "all" pour tout exporter
source_environment: "dev"           # environnement source
enable_gitops_cleanup: false        # nettoyage GitOps
```

### Workflow Automatique

1. **Déclenchement** : Exécution manuelle ou via trigger
2. **Export depuis Dev** : Export automatique des assets configurés
3. **Déploiement Accept** : Déploiement automatique avec overrides Accept
4. **Déploiement PreProd** : Déploiement automatique après Accept
5. **Déploiement Production** : Déploiement automatique après PreProd

## 🔧 Environment Overrides

Le système d'overrides permet d'adapter les configurations selon l'environnement. Ce mécanisme utilise les **Override Parameters** de QuickSight Asset Bundles.

📚 **Référence AWS** : [Override Parameters Documentation](https://docs.aws.amazon.com/quicksight/latest/APIReference/API_AssetBundleImportJobOverrideParameters.html)

### Types d'Overrides Supportés

#### **Datasources** - Connexions différentes par environnement
```json
{
  "DataSourceId": "mon-datasource",
  "environment_overrides": {
    "accept": {
      "DataSourceParameters": {
        "AuroraPostgreSqlParameters": {
          "Host": "accept-host.amazonaws.com",
          "Database": "accept_db"
        }
      },
      "Credentials": {
        "SecretArn": "arn:aws:secretsmanager:ca-central-1:968916078985:secret:accept-secret"
      }
    }
  }
}
```

#### **Themes** - Couleurs différentes par environnement
```json
{
  "ThemeId": "mon-theme",
  "environment_overrides": {
    "accept": {
      "Configuration": {
        "DataColorPalette": {
          "Colors": ["#1f77b4", "#ff7f0e", "#2ca02c"]
        }
      }
    },
    "prd": {
      "Configuration": {
        "DataColorPalette": {
          "Colors": ["#d62728", "#1f77b4", "#ff7f0e"]
        }
      }
    }
  }
}
```

## 📊 Surveillance et Logs

### Logs du Pipeline

Le pipeline génère des logs détaillés pour chaque étape :

```
🔍 Validating QuickSight export configuration
📊 Formation Configuration Summary:
  - Dashboards: 1
  - Datasets: 3  
  - Datasources: 1
  - Themes: 1
  - Total Assets: 6

✅ Validation PASSED: 6 assets configured for export

🚀 Starting QuickSight asset bundle export job...
✅ Export job completed successfully!

🎯 Deploying with account ID replacement + 2 parameter overrides
✅ Import completed successfully!
```

### Artefacts Générés

Le pipeline génère plusieurs artefacts :

- **`quicksight-export-complete`** - Bundle complet d'export
- **`validation-results`** - Résultats de validation
- **`deployment-results-Accept`** - Résultats déploiement Accept
- **`deployment-results-PreProd`** - Résultats déploiement PreProd
- **`deployment-results-Production`** - Résultats déploiement Production

## ⚠️ Prérequis et Permissions

### Permissions IAM Requises

Le service account doit avoir les permissions suivantes :

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "quicksight:ListDashboards",
        "quicksight:ListDataSets", 
        "quicksight:ListDataSources",
        "quicksight:ListAnalyses",
        "quicksight:ListThemes",
        "quicksight:StartAssetBundleExportJob",
        "quicksight:DescribeAssetBundleExportJob",
        "quicksight:StartAssetBundleImportJob",
        "quicksight:DescribeAssetBundleImportJob"
      ],
      "Resource": "*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "s3:PutObject",
        "s3:GetObject"
      ],
      "Resource": "arn:aws:s3:::deployment-bucket/*"
    }
  ]
}
```

### Ressources Requises

- **Buckets S3** de déploiement dans chaque environnement
- **Rôles IAM** configurés pour chaque environnement
- **Service accounts** avec permissions appropriées
- **QuickSight** activé dans tous les comptes/environnements

## 🛠️ Dépannage

### Erreurs Communes

#### **Assets non trouvés**
```
⚠️ WARNING: Some configured assets were not found in QuickSight account!
Expected: 6, Found: 4
  - Missing datasets: 2
```
**Solution** : Vérifier que les IDs dans formation.json correspondent aux assets existants

#### **Permissions insuffisantes**
```
❌ Failed to start export job
```
**Solution** : Vérifier les permissions IAM du service account

#### **Override manqué**
```
❌ Import job failed with status: FAILED
```
**Solution** : Vérifier que tous les overrides nécessaires sont configurés

### Validation des Configurations

Avant le déploiement, le pipeline valide :

- ✅ Syntaxe JSON de formation.json
- ✅ Existence des assets dans QuickSight source
- ✅ Structure des overrides d'environnement
- ✅ Références entre assets (ex: themes référençant des datasets)

## 📞 Support

Pour obtenir de l'aide :

### 1. **Logs du Pipeline**
Consulter les logs détaillés de chaque étape dans Azure DevOps pour identifier les problèmes.

### 2. **Commandes de Diagnostic**

#### Vérifier le statut d'un job d'import :
```bash
aws quicksight describe-asset-bundle-import-job \
  --aws-account-id "123456789012" \
  --asset-bundle-import-job-id "import-formation-accept-1672531200" \
  --region "ca-central-1"
```

#### Obtenir les détails des erreurs :
```bash
aws quicksight describe-asset-bundle-import-job \
  --aws-account-id "123456789012" \
  --asset-bundle-import-job-id "import-formation-accept-1672531200" \
  --region "ca-central-1" \
  --query 'Errors'
```

#### Lister les jobs d'import récents :
```bash
aws quicksight list-asset-bundle-import-jobs \
  --aws-account-id "123456789012" \
  --region "ca-central-1" \
  --max-results 20
```

#### Vérifier les assets QuickSight disponibles :
```bash
# Lister les dashboards
aws quicksight list-dashboards \
  --aws-account-id "123456789012" \
  --region "ca-central-1"

# Lister les datasets  
aws quicksight list-data-sets \
  --aws-account-id "123456789012" \
  --region "ca-central-1"

# Lister les themes
aws quicksight list-themes \
  --aws-account-id "123456789012" \
  --region "ca-central-1"
```

### 3. **Validation Manuelle**
Exécuter le pipeline en mode validation seulement pour tester les configurations sans déploiement.

### 4. **Documentation de Référence**

#### AWS QuickSight Asset Bundles :
- [Asset Bundle APIs](https://docs.aws.amazon.com/quicksight/latest/APIReference/API_Operations_Amazon_QuickSight.html)
- [Override Parameters](https://docs.aws.amazon.com/quicksight/latest/APIReference/API_AssetBundleImportJobOverrideParameters.html)
- [Export Job API](https://docs.aws.amazon.com/quicksight/latest/APIReference/API_StartAssetBundleExportJob.html)
- [Import Job API](https://docs.aws.amazon.com/quicksight/latest/APIReference/API_StartAssetBundleImportJob.html)

#### Azure DevOps Pipelines :
- [Pipeline YAML Schema](https://docs.microsoft.com/en-us/azure/devops/pipelines/yaml-schema)
- [Pipeline Variables](https://docs.microsoft.com/en-us/azure/devops/pipelines/process/variables)

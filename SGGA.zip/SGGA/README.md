# Pipelines de deploiements

Ce dépôt contient les définitions (yaml) des pipelines de déploiement pour le projet SGGA.

> 💡 Les déploiements s'appuient sur la plateforme d'hébergement ["ECS"](https://docs.aws.amazon.com/AmazonECS/latest/developerguide/Welcome.html).

## Processus

Un pipeline spécifique est défini pour chaque services du projet (consommateur-brio, actualiseur-brio, etc., ...). 

Les pipelines déploient en boucles sur les différents paliers (dev, accept, prod) du projet (voir ["multistage pipeline"](https://learn.microsoft.com/en-us/azure/devops/pipelines/process/create-multistage-pipeline?view=azure-devops)). Chaque palier corresponds à un "stage". 


Un "stage" de déploiment s'exécute selon cette séquence :

1. Publication de l'image sur ECR
    1. Authentification au compte AWS du registre source
    2. `docker pull` de l'image source
    3. authentification ver le registre ECR (`216016857543.dkr.ecr.ca-central-1.amazonaws.com`)
    4. `docker tag` de l'image cible et `docker push` vers ECR
2. Relancer le service ECS
    1. authentification au compte AWS du service de l'environement ciblé
    2. relancer le service ECS ciblé

## Séquences, environnement et approbations

Les pipelines s'exécutent séquenciellement suivant cet ordre :

- Déploiement vers "dev"
- Déploiement vers "accept"
- Déploiement vers "preprod"
- Déploiement vers "prod"

> 💡 Un processus d'approbation peut être attaché pour chaque environnements de la séquence. (voir "Approvals and checks" au niveau des [environnements](https://dev.azure.com/GouvQC/SGGA/_environments/))

Advenant tout échec (erreur), ou advenant le refus d'une séquence, l'exécution du pipeline est arrêtée.


## Authentification

La procédure d'authentification est 

Les comptes de services définis dans au niveau des [groupes de variables](https://dev.azure.com/GouvQC/SGGA/_library?itemType=VariableGroups) permettent à l'agent qui exécute le pipeline de s'authentifier dans la zone d'accueil AWS  assumer le rôle (IAM) requis. 

Un compte de service est défini par palier :

- dev => sgga_cicd_dev
- accept => sgga_cicd_tst
- preprod => sgga_cicd_tst
- prod => sgga_cicd_prd

> 💡 Voir [processus-d'authentification-et-d'autorisation (ALM)](https://dev.azure.com/GouvQC/DevSecOps-DSD/_wiki/wikis/DevSecOps-DSD.wiki/3217/Processus-d'authentification-et-d'autorisation)


## Références

- Gabarit des pipelines
    - Fichiers locaux
        - [deploy-ecs-multistages](Deploy/templates/deploy-ecs-multistages.yaml)
        - [deploy-ecs](Deploy/templates/deploy-ecs.yaml)
    - [pipeline_templates](https://dev.azure.com/GouvQC/SD/_git/pipeline_templates)
- Variables d'environnements des différents paliers :
    - [dev](Deploy/environments/dev.yaml)
    - [accept](Deploy/environments/accept.yaml)
    - [proprod](Deploy/environments/preprod.yaml)
    - [prod](Deploy/environments/prod.yaml)

- [Environnements du projet](https://dev.azure.com/GouvQC/SGGA/_environments/)
- Comptes AWS de la [zone d'accueil](https://gqc.awsapps.com/start/#/?tab=accounts)
    - 0796-sgga-dev (216016857543)
    - 0796-sgga-tst (968916078985)
    - 0796-sgga-prd (889715954559)
- [Processus-d'authentification-et-d'autorisation (ALM)](https://dev.azure.com/GouvQC/DevSecOps-DSD/_wiki/wikis/DevSecOps-DSD.wiki/3217/Processus-d'authentification-et-d'autorisation)